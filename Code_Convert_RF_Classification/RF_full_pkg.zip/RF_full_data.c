/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: RF_full_data.c
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 28-Aug-2020 20:59:21
 */

/* Include Files */
#include "RF_full_data.h"
#include "RF_full.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
boolean_T isInitialized_RF_full = false;

/*
 * File trailer for RF_full_data.c
 *
 * [EOF]
 */
