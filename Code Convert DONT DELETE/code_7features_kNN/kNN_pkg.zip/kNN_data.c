/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: kNN_data.c
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 06-May-2021 23:36:41
 */

/* Include Files */
#include "kNN_data.h"
#include "kNN.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
boolean_T isInitialized_kNN = false;

/*
 * File trailer for kNN_data.c
 *
 * [EOF]
 */
