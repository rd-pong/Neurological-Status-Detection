/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: bsxfun.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 06-May-2021 23:36:41
 */

#ifndef BSXFUN_H
#define BSXFUN_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "kNN_types.h"

/* Function Declarations */
extern void bsxfun(const emxArray_real_T *a, const double b[7], emxArray_real_T *
                   c);

#endif

/*
 * File trailer for bsxfun.h
 *
 * [EOF]
 */
