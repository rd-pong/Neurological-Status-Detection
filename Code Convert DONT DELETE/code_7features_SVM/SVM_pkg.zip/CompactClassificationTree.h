/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: CompactClassificationTree.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 07-May-2021 09:14:42
 */

#ifndef COMPACTCLASSIFICATIONTREE_H
#define COMPACTCLASSIFICATIONTREE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "RF_full_types.h"

/* Function Declarations */
extern void c_CompactClassificationTree_Com(double obj_CutPredictorIndex[1357],
  double obj_Children[2714], double obj_CutPoint[1357], bool obj_NanCutPoints
  [1357], bool obj_InfCutPoints[1357], double obj_ClassNames[4], int
  obj_ClassNamesLength[4], c_classreg_learning_coderutils_ *obj_ScoreTransform,
  double obj_Prior[4], bool obj_ClassLogicalIndices[4], double obj_Cost[16],
  double obj_ClassProbability[5428]);
extern void c_CompactClassificationTree_pre(const double obj_CutPredictorIndex
  [1357], const double obj_Children[2714], const double obj_CutPoint[1357],
  const bool obj_NanCutPoints[1357], const double obj_ClassNames[4], const
  double obj_Cost[16], const double obj_ClassProbability[5428], const double X[7],
  double *labels, double scores[4]);
extern void d_CompactClassificationTree_Com(double obj_CutPredictorIndex[1435],
  double obj_Children[2870], double obj_CutPoint[1435], bool obj_NanCutPoints
  [1435], bool obj_InfCutPoints[1435], double obj_ClassNames[4], int
  obj_ClassNamesLength[4], c_classreg_learning_coderutils_ *obj_ScoreTransform,
  double obj_Prior[4], bool obj_ClassLogicalIndices[4], double obj_Cost[16],
  double obj_ClassProbability[5740]);
extern void d_CompactClassificationTree_pre(const double obj_CutPredictorIndex
  [1435], const double obj_Children[2870], const double obj_CutPoint[1435],
  const bool obj_NanCutPoints[1435], const double obj_ClassNames[4], const
  double obj_Cost[16], const double obj_ClassProbability[5740], const double X[7],
  double *labels, double scores[4]);
extern void e_CompactClassificationTree_Com(double obj_CutPredictorIndex[1443],
  double obj_Children[2886], double obj_CutPoint[1443], bool obj_NanCutPoints
  [1443], bool obj_InfCutPoints[1443], double obj_ClassNames[4], int
  obj_ClassNamesLength[4], c_classreg_learning_coderutils_ *obj_ScoreTransform,
  double obj_Prior[4], bool obj_ClassLogicalIndices[4], double obj_Cost[16],
  double obj_ClassProbability[5772]);
extern void e_CompactClassificationTree_pre(const double obj_CutPredictorIndex
  [1443], const double obj_Children[2886], const double obj_CutPoint[1443],
  const bool obj_NanCutPoints[1443], const double obj_ClassNames[4], const
  double obj_Cost[16], const double obj_ClassProbability[5772], const double X[7],
  double *labels, double scores[4]);
extern void f_CompactClassificationTree_Com(double obj_CutPredictorIndex[1437],
  double obj_Children[2874], double obj_CutPoint[1437], bool obj_NanCutPoints
  [1437], bool obj_InfCutPoints[1437], double obj_ClassNames[4], int
  obj_ClassNamesLength[4], c_classreg_learning_coderutils_ *obj_ScoreTransform,
  double obj_Prior[4], bool obj_ClassLogicalIndices[4], double obj_Cost[16],
  double obj_ClassProbability[5748]);
extern void f_CompactClassificationTree_pre(const double obj_CutPredictorIndex
  [1437], const double obj_Children[2874], const double obj_CutPoint[1437],
  const bool obj_NanCutPoints[1437], const double obj_ClassNames[4], const
  double obj_Cost[16], const double obj_ClassProbability[5748], const double X[7],
  double *labels, double scores[4]);
extern void g_CompactClassificationTree_Com(double obj_CutPredictorIndex[1419],
  double obj_Children[2838], double obj_CutPoint[1419], bool obj_NanCutPoints
  [1419], bool obj_InfCutPoints[1419], double obj_ClassNames[4], int
  obj_ClassNamesLength[4], c_classreg_learning_coderutils_ *obj_ScoreTransform,
  double obj_Prior[4], bool obj_ClassLogicalIndices[4], double obj_Cost[16],
  double obj_ClassProbability[5676]);
extern void g_CompactClassificationTree_pre(const double obj_CutPredictorIndex
  [1419], const double obj_Children[2838], const double obj_CutPoint[1419],
  const bool obj_NanCutPoints[1419], const double obj_ClassNames[4], const
  double obj_Cost[16], const double obj_ClassProbability[5676], const double X[7],
  double *labels, double scores[4]);

#endif

/*
 * File trailer for CompactClassificationTree.h
 *
 * [EOF]
 */
