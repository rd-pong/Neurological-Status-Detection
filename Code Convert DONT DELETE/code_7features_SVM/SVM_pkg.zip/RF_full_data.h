/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: RF_full_data.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 07-May-2021 09:14:42
 */

#ifndef RF_FULL_DATA_H
#define RF_FULL_DATA_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "RF_full_types.h"

/* Variable Declarations */
extern boolean_T isInitialized_RF_full;

#endif

/*
 * File trailer for RF_full_data.h
 *
 * [EOF]
 */
