/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: predictOneWithCache.c
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 07-May-2021 09:14:42
 */

/* Include Files */
#include "predictOneWithCache.h"
#include "CompactClassificationTree.h"
#include "RF_full.h"
#include "rt_nonfinite.h"
#include "updateCache.h"
#include <math.h>

/* Function Definitions */

/*
 * Arguments    : const double X[7]
 *                double cachedScore[4]
 *                double *cachedWeights
 *                const char combiner[15]
 *                const double weak_learner_CutPredictorIndex[1435]
 *                const double weak_learner_Children[2870]
 *                const double weak_learner_CutPoint[1435]
 *                const bool weak_learner_NanCutPoints[1435]
 *                const double weak_learner_ClassNames[4]
 *                const double weak_learner_Cost[16]
 *                const double weak_learner_ClassProbability[5740]
 *                bool *cached
 *                const double classnames[4]
 *                bool initCache
 *                double score[4]
 * Return Type  : void
 */
void b_predictOneWithCache(const double X[7], double cachedScore[4], double
  *cachedWeights, const char combiner[15], const double
  weak_learner_CutPredictorIndex[1435], const double weak_learner_Children[2870],
  const double weak_learner_CutPoint[1435], const bool
  weak_learner_NanCutPoints[1435], const double weak_learner_ClassNames[4],
  const double weak_learner_Cost[16], const double
  weak_learner_ClassProbability[5740], bool *cached, const double classnames[4],
  bool initCache, double score[4])
{
  double learnerscore[4];
  int iloc_idx_0;
  int i;
  bool exitg1;
  int iloc_idx_1;
  double absx;
  int exponent;
  int iloc_idx_2;
  int iloc_idx_3;
  double dv[4];
  bool tf[4];
  bool y;
  learnerscore[0] = rtNaN;
  learnerscore[1] = rtNaN;
  learnerscore[2] = rtNaN;
  learnerscore[3] = rtNaN;
  iloc_idx_0 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[0]) < absx) {
      iloc_idx_0 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  iloc_idx_1 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[1]) < absx) {
      iloc_idx_1 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  iloc_idx_2 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[2]) < absx) {
      iloc_idx_2 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  iloc_idx_3 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[3]) < absx) {
      iloc_idx_3 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  d_CompactClassificationTree_pre(weak_learner_CutPredictorIndex,
    weak_learner_Children, weak_learner_CutPoint, weak_learner_NanCutPoints,
    weak_learner_ClassNames, weak_learner_Cost, weak_learner_ClassProbability, X,
    &absx, dv);
  learnerscore[iloc_idx_0 - 1] = dv[0];
  learnerscore[iloc_idx_1 - 1] = dv[1];
  learnerscore[iloc_idx_2 - 1] = dv[2];
  learnerscore[iloc_idx_3 - 1] = dv[3];
  if (initCache) {
    cachedScore[0] = 0.0;
    cachedScore[1] = 0.0;
    cachedScore[2] = 0.0;
    cachedScore[3] = 0.0;
  } else {
    tf[0] = rtIsNaN(cachedScore[0]);
    tf[1] = rtIsNaN(cachedScore[1]);
    tf[2] = rtIsNaN(cachedScore[2]);
    tf[3] = rtIsNaN(cachedScore[3]);
    y = false;
    iloc_idx_0 = 0;
    exitg1 = false;
    while ((!exitg1) && (iloc_idx_0 < 4)) {
      if (tf[iloc_idx_0]) {
        y = true;
        exitg1 = true;
      } else {
        iloc_idx_0++;
      }
    }

    if (y) {
      if (tf[0]) {
        cachedScore[0] = 0.0;
      }

      if (tf[1]) {
        cachedScore[1] = 0.0;
      }

      if (tf[2]) {
        cachedScore[2] = 0.0;
      }

      if (tf[3]) {
        cachedScore[3] = 0.0;
      }
    }
  }

  *cached = false;
  updateCache(learnerscore, cachedScore, cachedWeights, cached, combiner, score);
}

/*
 * Arguments    : const double X[7]
 *                double cachedScore[4]
 *                double *cachedWeights
 *                const char combiner[15]
 *                const double weak_learner_CutPredictorIndex[1443]
 *                const double weak_learner_Children[2886]
 *                const double weak_learner_CutPoint[1443]
 *                const bool weak_learner_NanCutPoints[1443]
 *                const double weak_learner_ClassNames[4]
 *                const double weak_learner_Cost[16]
 *                const double weak_learner_ClassProbability[5772]
 *                bool *cached
 *                const double classnames[4]
 *                bool initCache
 *                double score[4]
 * Return Type  : void
 */
void c_predictOneWithCache(const double X[7], double cachedScore[4], double
  *cachedWeights, const char combiner[15], const double
  weak_learner_CutPredictorIndex[1443], const double weak_learner_Children[2886],
  const double weak_learner_CutPoint[1443], const bool
  weak_learner_NanCutPoints[1443], const double weak_learner_ClassNames[4],
  const double weak_learner_Cost[16], const double
  weak_learner_ClassProbability[5772], bool *cached, const double classnames[4],
  bool initCache, double score[4])
{
  double learnerscore[4];
  int iloc_idx_0;
  int i;
  bool exitg1;
  int iloc_idx_1;
  double absx;
  int exponent;
  int iloc_idx_2;
  int iloc_idx_3;
  double dv[4];
  bool tf[4];
  bool y;
  learnerscore[0] = rtNaN;
  learnerscore[1] = rtNaN;
  learnerscore[2] = rtNaN;
  learnerscore[3] = rtNaN;
  iloc_idx_0 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[0]) < absx) {
      iloc_idx_0 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  iloc_idx_1 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[1]) < absx) {
      iloc_idx_1 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  iloc_idx_2 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[2]) < absx) {
      iloc_idx_2 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  iloc_idx_3 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[3]) < absx) {
      iloc_idx_3 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  e_CompactClassificationTree_pre(weak_learner_CutPredictorIndex,
    weak_learner_Children, weak_learner_CutPoint, weak_learner_NanCutPoints,
    weak_learner_ClassNames, weak_learner_Cost, weak_learner_ClassProbability, X,
    &absx, dv);
  learnerscore[iloc_idx_0 - 1] = dv[0];
  learnerscore[iloc_idx_1 - 1] = dv[1];
  learnerscore[iloc_idx_2 - 1] = dv[2];
  learnerscore[iloc_idx_3 - 1] = dv[3];
  if (initCache) {
    cachedScore[0] = 0.0;
    cachedScore[1] = 0.0;
    cachedScore[2] = 0.0;
    cachedScore[3] = 0.0;
  } else {
    tf[0] = rtIsNaN(cachedScore[0]);
    tf[1] = rtIsNaN(cachedScore[1]);
    tf[2] = rtIsNaN(cachedScore[2]);
    tf[3] = rtIsNaN(cachedScore[3]);
    y = false;
    iloc_idx_0 = 0;
    exitg1 = false;
    while ((!exitg1) && (iloc_idx_0 < 4)) {
      if (tf[iloc_idx_0]) {
        y = true;
        exitg1 = true;
      } else {
        iloc_idx_0++;
      }
    }

    if (y) {
      if (tf[0]) {
        cachedScore[0] = 0.0;
      }

      if (tf[1]) {
        cachedScore[1] = 0.0;
      }

      if (tf[2]) {
        cachedScore[2] = 0.0;
      }

      if (tf[3]) {
        cachedScore[3] = 0.0;
      }
    }
  }

  *cached = false;
  updateCache(learnerscore, cachedScore, cachedWeights, cached, combiner, score);
}

/*
 * Arguments    : const double X[7]
 *                double cachedScore[4]
 *                double *cachedWeights
 *                const char combiner[15]
 *                const double weak_learner_CutPredictorIndex[1437]
 *                const double weak_learner_Children[2874]
 *                const double weak_learner_CutPoint[1437]
 *                const bool weak_learner_NanCutPoints[1437]
 *                const double weak_learner_ClassNames[4]
 *                const double weak_learner_Cost[16]
 *                const double weak_learner_ClassProbability[5748]
 *                bool *cached
 *                const double classnames[4]
 *                bool initCache
 *                double score[4]
 * Return Type  : void
 */
void d_predictOneWithCache(const double X[7], double cachedScore[4], double
  *cachedWeights, const char combiner[15], const double
  weak_learner_CutPredictorIndex[1437], const double weak_learner_Children[2874],
  const double weak_learner_CutPoint[1437], const bool
  weak_learner_NanCutPoints[1437], const double weak_learner_ClassNames[4],
  const double weak_learner_Cost[16], const double
  weak_learner_ClassProbability[5748], bool *cached, const double classnames[4],
  bool initCache, double score[4])
{
  double learnerscore[4];
  int iloc_idx_0;
  int i;
  bool exitg1;
  int iloc_idx_1;
  double absx;
  int exponent;
  int iloc_idx_2;
  int iloc_idx_3;
  double dv[4];
  bool tf[4];
  bool y;
  learnerscore[0] = rtNaN;
  learnerscore[1] = rtNaN;
  learnerscore[2] = rtNaN;
  learnerscore[3] = rtNaN;
  iloc_idx_0 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[0]) < absx) {
      iloc_idx_0 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  iloc_idx_1 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[1]) < absx) {
      iloc_idx_1 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  iloc_idx_2 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[2]) < absx) {
      iloc_idx_2 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  iloc_idx_3 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[3]) < absx) {
      iloc_idx_3 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  f_CompactClassificationTree_pre(weak_learner_CutPredictorIndex,
    weak_learner_Children, weak_learner_CutPoint, weak_learner_NanCutPoints,
    weak_learner_ClassNames, weak_learner_Cost, weak_learner_ClassProbability, X,
    &absx, dv);
  learnerscore[iloc_idx_0 - 1] = dv[0];
  learnerscore[iloc_idx_1 - 1] = dv[1];
  learnerscore[iloc_idx_2 - 1] = dv[2];
  learnerscore[iloc_idx_3 - 1] = dv[3];
  if (initCache) {
    cachedScore[0] = 0.0;
    cachedScore[1] = 0.0;
    cachedScore[2] = 0.0;
    cachedScore[3] = 0.0;
  } else {
    tf[0] = rtIsNaN(cachedScore[0]);
    tf[1] = rtIsNaN(cachedScore[1]);
    tf[2] = rtIsNaN(cachedScore[2]);
    tf[3] = rtIsNaN(cachedScore[3]);
    y = false;
    iloc_idx_0 = 0;
    exitg1 = false;
    while ((!exitg1) && (iloc_idx_0 < 4)) {
      if (tf[iloc_idx_0]) {
        y = true;
        exitg1 = true;
      } else {
        iloc_idx_0++;
      }
    }

    if (y) {
      if (tf[0]) {
        cachedScore[0] = 0.0;
      }

      if (tf[1]) {
        cachedScore[1] = 0.0;
      }

      if (tf[2]) {
        cachedScore[2] = 0.0;
      }

      if (tf[3]) {
        cachedScore[3] = 0.0;
      }
    }
  }

  *cached = false;
  updateCache(learnerscore, cachedScore, cachedWeights, cached, combiner, score);
}

/*
 * Arguments    : const double X[7]
 *                double cachedScore[4]
 *                double *cachedWeights
 *                const char combiner[15]
 *                const double weak_learner_CutPredictorIndex[1419]
 *                const double weak_learner_Children[2838]
 *                const double weak_learner_CutPoint[1419]
 *                const bool weak_learner_NanCutPoints[1419]
 *                const double weak_learner_ClassNames[4]
 *                const double weak_learner_Cost[16]
 *                const double weak_learner_ClassProbability[5676]
 *                bool *cached
 *                const double classnames[4]
 *                bool initCache
 *                double score[4]
 * Return Type  : void
 */
void e_predictOneWithCache(const double X[7], double cachedScore[4], double
  *cachedWeights, const char combiner[15], const double
  weak_learner_CutPredictorIndex[1419], const double weak_learner_Children[2838],
  const double weak_learner_CutPoint[1419], const bool
  weak_learner_NanCutPoints[1419], const double weak_learner_ClassNames[4],
  const double weak_learner_Cost[16], const double
  weak_learner_ClassProbability[5676], bool *cached, const double classnames[4],
  bool initCache, double score[4])
{
  double learnerscore[4];
  int iloc_idx_0;
  int i;
  bool exitg1;
  int iloc_idx_1;
  double absx;
  int exponent;
  int iloc_idx_2;
  int iloc_idx_3;
  double dv[4];
  bool tf[4];
  bool y;
  learnerscore[0] = rtNaN;
  learnerscore[1] = rtNaN;
  learnerscore[2] = rtNaN;
  learnerscore[3] = rtNaN;
  iloc_idx_0 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[0]) < absx) {
      iloc_idx_0 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  iloc_idx_1 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[1]) < absx) {
      iloc_idx_1 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  iloc_idx_2 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[2]) < absx) {
      iloc_idx_2 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  iloc_idx_3 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[3]) < absx) {
      iloc_idx_3 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  g_CompactClassificationTree_pre(weak_learner_CutPredictorIndex,
    weak_learner_Children, weak_learner_CutPoint, weak_learner_NanCutPoints,
    weak_learner_ClassNames, weak_learner_Cost, weak_learner_ClassProbability, X,
    &absx, dv);
  learnerscore[iloc_idx_0 - 1] = dv[0];
  learnerscore[iloc_idx_1 - 1] = dv[1];
  learnerscore[iloc_idx_2 - 1] = dv[2];
  learnerscore[iloc_idx_3 - 1] = dv[3];
  if (initCache) {
    cachedScore[0] = 0.0;
    cachedScore[1] = 0.0;
    cachedScore[2] = 0.0;
    cachedScore[3] = 0.0;
  } else {
    tf[0] = rtIsNaN(cachedScore[0]);
    tf[1] = rtIsNaN(cachedScore[1]);
    tf[2] = rtIsNaN(cachedScore[2]);
    tf[3] = rtIsNaN(cachedScore[3]);
    y = false;
    iloc_idx_0 = 0;
    exitg1 = false;
    while ((!exitg1) && (iloc_idx_0 < 4)) {
      if (tf[iloc_idx_0]) {
        y = true;
        exitg1 = true;
      } else {
        iloc_idx_0++;
      }
    }

    if (y) {
      if (tf[0]) {
        cachedScore[0] = 0.0;
      }

      if (tf[1]) {
        cachedScore[1] = 0.0;
      }

      if (tf[2]) {
        cachedScore[2] = 0.0;
      }

      if (tf[3]) {
        cachedScore[3] = 0.0;
      }
    }
  }

  *cached = false;
  updateCache(learnerscore, cachedScore, cachedWeights, cached, combiner, score);
}

/*
 * Arguments    : const double X[7]
 *                double cachedScore[4]
 *                double *cachedWeights
 *                const char combiner[15]
 *                const double weak_learner_CutPredictorIndex[1357]
 *                const double weak_learner_Children[2714]
 *                const double weak_learner_CutPoint[1357]
 *                const bool weak_learner_NanCutPoints[1357]
 *                const double weak_learner_ClassNames[4]
 *                const double weak_learner_Cost[16]
 *                const double weak_learner_ClassProbability[5428]
 *                bool *cached
 *                const double classnames[4]
 *                double score[4]
 * Return Type  : void
 */
void predictOneWithCache(const double X[7], double cachedScore[4], double
  *cachedWeights, const char combiner[15], const double
  weak_learner_CutPredictorIndex[1357], const double weak_learner_Children[2714],
  const double weak_learner_CutPoint[1357], const bool
  weak_learner_NanCutPoints[1357], const double weak_learner_ClassNames[4],
  const double weak_learner_Cost[16], const double
  weak_learner_ClassProbability[5428], bool *cached, const double classnames[4],
  double score[4])
{
  double learnerscore[4];
  int iloc_idx_0;
  int i;
  bool exitg1;
  int iloc_idx_1;
  double absx;
  int exponent;
  int iloc_idx_2;
  int iloc_idx_3;
  double dv[4];
  learnerscore[0] = rtNaN;
  learnerscore[1] = rtNaN;
  learnerscore[2] = rtNaN;
  learnerscore[3] = rtNaN;
  iloc_idx_0 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[0]) < absx) {
      iloc_idx_0 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  iloc_idx_1 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[1]) < absx) {
      iloc_idx_1 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  iloc_idx_2 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[2]) < absx) {
      iloc_idx_2 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  iloc_idx_3 = 0;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 4)) {
    absx = fabs(classnames[i] / 2.0);
    if (absx <= 2.2250738585072014E-308) {
      absx = 4.94065645841247E-324;
    } else {
      frexp(absx, &exponent);
      absx = ldexp(1.0, exponent - 53);
    }

    if (fabs(classnames[i] - weak_learner_ClassNames[3]) < absx) {
      iloc_idx_3 = i + 1;
      exitg1 = true;
    } else {
      i++;
    }
  }

  c_CompactClassificationTree_pre(weak_learner_CutPredictorIndex,
    weak_learner_Children, weak_learner_CutPoint, weak_learner_NanCutPoints,
    weak_learner_ClassNames, weak_learner_Cost, weak_learner_ClassProbability, X,
    &absx, dv);
  learnerscore[iloc_idx_0 - 1] = dv[0];
  cachedScore[0] = 0.0;
  learnerscore[iloc_idx_1 - 1] = dv[1];
  cachedScore[1] = 0.0;
  learnerscore[iloc_idx_2 - 1] = dv[2];
  cachedScore[2] = 0.0;
  learnerscore[iloc_idx_3 - 1] = dv[3];
  cachedScore[3] = 0.0;
  *cachedWeights = 0.0;
  *cached = false;
  updateCache(learnerscore, cachedScore, cachedWeights, cached, combiner, score);
}

/*
 * File trailer for predictOneWithCache.c
 *
 * [EOF]
 */
