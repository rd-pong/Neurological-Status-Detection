/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: predictOneWithCache.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 07-May-2021 09:14:42
 */

#ifndef PREDICTONEWITHCACHE_H
#define PREDICTONEWITHCACHE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "RF_full_types.h"

/* Function Declarations */
extern void b_predictOneWithCache(const double X[7], double cachedScore[4],
  double *cachedWeights, const char combiner[15], const double
  weak_learner_CutPredictorIndex[1435], const double weak_learner_Children[2870],
  const double weak_learner_CutPoint[1435], const bool
  weak_learner_NanCutPoints[1435], const double weak_learner_ClassNames[4],
  const double weak_learner_Cost[16], const double
  weak_learner_ClassProbability[5740], bool *cached, const double classnames[4],
  bool initCache, double score[4]);
extern void c_predictOneWithCache(const double X[7], double cachedScore[4],
  double *cachedWeights, const char combiner[15], const double
  weak_learner_CutPredictorIndex[1443], const double weak_learner_Children[2886],
  const double weak_learner_CutPoint[1443], const bool
  weak_learner_NanCutPoints[1443], const double weak_learner_ClassNames[4],
  const double weak_learner_Cost[16], const double
  weak_learner_ClassProbability[5772], bool *cached, const double classnames[4],
  bool initCache, double score[4]);
extern void d_predictOneWithCache(const double X[7], double cachedScore[4],
  double *cachedWeights, const char combiner[15], const double
  weak_learner_CutPredictorIndex[1437], const double weak_learner_Children[2874],
  const double weak_learner_CutPoint[1437], const bool
  weak_learner_NanCutPoints[1437], const double weak_learner_ClassNames[4],
  const double weak_learner_Cost[16], const double
  weak_learner_ClassProbability[5748], bool *cached, const double classnames[4],
  bool initCache, double score[4]);
extern void e_predictOneWithCache(const double X[7], double cachedScore[4],
  double *cachedWeights, const char combiner[15], const double
  weak_learner_CutPredictorIndex[1419], const double weak_learner_Children[2838],
  const double weak_learner_CutPoint[1419], const bool
  weak_learner_NanCutPoints[1419], const double weak_learner_ClassNames[4],
  const double weak_learner_Cost[16], const double
  weak_learner_ClassProbability[5676], bool *cached, const double classnames[4],
  bool initCache, double score[4]);
extern void predictOneWithCache(const double X[7], double cachedScore[4], double
  *cachedWeights, const char combiner[15], const double
  weak_learner_CutPredictorIndex[1357], const double weak_learner_Children[2714],
  const double weak_learner_CutPoint[1357], const bool
  weak_learner_NanCutPoints[1357], const double weak_learner_ClassNames[4],
  const double weak_learner_Cost[16], const double
  weak_learner_ClassProbability[5428], bool *cached, const double classnames[4],
  double score[4]);

#endif

/*
 * File trailer for predictOneWithCache.h
 *
 * [EOF]
 */
