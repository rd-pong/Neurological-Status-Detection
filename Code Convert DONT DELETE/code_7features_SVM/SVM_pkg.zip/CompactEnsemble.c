/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: CompactEnsemble.c
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 07-May-2021 09:14:42
 */

/* Include Files */
#include "CompactEnsemble.h"
#include "CompactClassificationTree.h"
#include "RF_full.h"
#include "predictOneWithCache.h"
#include "rt_nonfinite.h"

/* Function Definitions */

/*
 * Arguments    : const double X[7]
 *                const double classnames[4]
 *                double score[4]
 * Return Type  : void
 */
void CompactEnsemble_ensemblePredict(const double X[7], const double classnames
  [4], double score[4])
{
  double weak_learner_CutPredictorIndex[1357];
  double weak_learner_Children[2714];
  double weak_learner_CutPoint[1357];
  bool weak_learner_NanCutPoints[1357];
  bool expl_temp[1357];
  double weak_learner_ClassNames[4];
  int b_expl_temp[4];
  c_classreg_learning_coderutils_ c_expl_temp;
  double d_expl_temp[4];
  bool e_expl_temp[4];
  double weak_learner_Cost[16];
  static double weak_learner_ClassProbability[5428];
  double cachedScore[4];
  double cachedWeights;
  bool b;
  static const char combiner[15] = { 'W', 'e', 'i', 'g', 'h', 't', 'e', 'd', 'A',
    'v', 'e', 'r', 'a', 'g', 'e' };

  double b_weak_learner_CutPredictorInde[1435];
  double b_weak_learner_Children[2870];
  double b_weak_learner_CutPoint[1435];
  bool b_weak_learner_NanCutPoints[1435];
  bool f_expl_temp[1435];
  static double b_weak_learner_ClassProbability[5740];
  double c_weak_learner_CutPredictorInde[1443];
  static double c_weak_learner_Children[2886];
  double c_weak_learner_CutPoint[1443];
  bool c_weak_learner_NanCutPoints[1443];
  bool g_expl_temp[1443];
  static double c_weak_learner_ClassProbability[5772];
  double d_weak_learner_CutPredictorInde[1437];
  static double d_weak_learner_Children[2874];
  double d_weak_learner_CutPoint[1437];
  bool d_weak_learner_NanCutPoints[1437];
  bool h_expl_temp[1437];
  static double d_weak_learner_ClassProbability[5748];
  double e_weak_learner_CutPredictorInde[1419];
  double e_weak_learner_Children[2838];
  double e_weak_learner_CutPoint[1419];
  bool e_weak_learner_NanCutPoints[1419];
  bool i_expl_temp[1419];
  static double e_weak_learner_ClassProbability[5676];
  c_CompactClassificationTree_Com(weak_learner_CutPredictorIndex,
    weak_learner_Children, weak_learner_CutPoint, weak_learner_NanCutPoints,
    expl_temp, weak_learner_ClassNames, b_expl_temp, &c_expl_temp, d_expl_temp,
    e_expl_temp, weak_learner_Cost, weak_learner_ClassProbability);
  cachedScore[0] = 0.0;
  cachedScore[1] = 0.0;
  cachedScore[2] = 0.0;
  cachedScore[3] = 0.0;
  cachedWeights = 0.0;
  b = false;
  predictOneWithCache(X, cachedScore, &cachedWeights, combiner,
                      weak_learner_CutPredictorIndex, weak_learner_Children,
                      weak_learner_CutPoint, weak_learner_NanCutPoints,
                      weak_learner_ClassNames, weak_learner_Cost,
                      weak_learner_ClassProbability, &b, classnames, d_expl_temp);
  d_CompactClassificationTree_Com(b_weak_learner_CutPredictorInde,
    b_weak_learner_Children, b_weak_learner_CutPoint,
    b_weak_learner_NanCutPoints, f_expl_temp, weak_learner_ClassNames,
    b_expl_temp, &c_expl_temp, d_expl_temp, e_expl_temp, weak_learner_Cost,
    b_weak_learner_ClassProbability);
  b = false;
  b_predictOneWithCache(X, cachedScore, &cachedWeights, combiner,
                        b_weak_learner_CutPredictorInde, b_weak_learner_Children,
                        b_weak_learner_CutPoint, b_weak_learner_NanCutPoints,
                        weak_learner_ClassNames, weak_learner_Cost,
                        b_weak_learner_ClassProbability, &b, classnames, false,
                        d_expl_temp);
  e_CompactClassificationTree_Com(c_weak_learner_CutPredictorInde,
    c_weak_learner_Children, c_weak_learner_CutPoint,
    c_weak_learner_NanCutPoints, g_expl_temp, weak_learner_ClassNames,
    b_expl_temp, &c_expl_temp, d_expl_temp, e_expl_temp, weak_learner_Cost,
    c_weak_learner_ClassProbability);
  b = false;
  c_predictOneWithCache(X, cachedScore, &cachedWeights, combiner,
                        c_weak_learner_CutPredictorInde, c_weak_learner_Children,
                        c_weak_learner_CutPoint, c_weak_learner_NanCutPoints,
                        weak_learner_ClassNames, weak_learner_Cost,
                        c_weak_learner_ClassProbability, &b, classnames, false,
                        d_expl_temp);
  f_CompactClassificationTree_Com(d_weak_learner_CutPredictorInde,
    d_weak_learner_Children, d_weak_learner_CutPoint,
    d_weak_learner_NanCutPoints, h_expl_temp, weak_learner_ClassNames,
    b_expl_temp, &c_expl_temp, d_expl_temp, e_expl_temp, weak_learner_Cost,
    d_weak_learner_ClassProbability);
  b = false;
  d_predictOneWithCache(X, cachedScore, &cachedWeights, combiner,
                        d_weak_learner_CutPredictorInde, d_weak_learner_Children,
                        d_weak_learner_CutPoint, d_weak_learner_NanCutPoints,
                        weak_learner_ClassNames, weak_learner_Cost,
                        d_weak_learner_ClassProbability, &b, classnames, false,
                        d_expl_temp);
  g_CompactClassificationTree_Com(e_weak_learner_CutPredictorInde,
    e_weak_learner_Children, e_weak_learner_CutPoint,
    e_weak_learner_NanCutPoints, i_expl_temp, weak_learner_ClassNames,
    b_expl_temp, &c_expl_temp, d_expl_temp, e_expl_temp, weak_learner_Cost,
    e_weak_learner_ClassProbability);
  b = false;
  e_predictOneWithCache(X, cachedScore, &cachedWeights, combiner,
                        e_weak_learner_CutPredictorInde, e_weak_learner_Children,
                        e_weak_learner_CutPoint, e_weak_learner_NanCutPoints,
                        weak_learner_ClassNames, weak_learner_Cost,
                        e_weak_learner_ClassProbability, &b, classnames, false,
                        score);
}

/*
 * File trailer for CompactEnsemble.c
 *
 * [EOF]
 */
