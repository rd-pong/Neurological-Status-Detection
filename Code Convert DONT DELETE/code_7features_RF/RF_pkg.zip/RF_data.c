/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: RF_data.c
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 07-May-2021 10:01:49
 */

/* Include Files */
#include "RF_data.h"
#include "RF.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
boolean_T isInitialized_RF = false;

/*
 * File trailer for RF_data.c
 *
 * [EOF]
 */
