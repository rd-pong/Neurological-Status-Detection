/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: SVM_full.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 28-Aug-2020 22:51:15
 */

#ifndef SVM_FULL_H
#define SVM_FULL_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "SVM_full_types.h"

/* Function Declarations */
extern void SVM_full(const double input_data[28], double *label, double score[4]);

#endif

/*
 * File trailer for SVM_full.h
 *
 * [EOF]
 */
