/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: SVM_full_terminate.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 28-Aug-2020 22:51:15
 */

#ifndef SVM_FULL_TERMINATE_H
#define SVM_FULL_TERMINATE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "SVM_full_types.h"

/* Function Declarations */
extern void SVM_full_terminate(void);

#endif

/*
 * File trailer for SVM_full_terminate.h
 *
 * [EOF]
 */
