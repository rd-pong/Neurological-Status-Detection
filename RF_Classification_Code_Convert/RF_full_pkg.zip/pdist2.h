/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: pdist2.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 28-Aug-2020 15:49:21
 */

#ifndef PDIST2_H
#define PDIST2_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "RF_full_types.h"

/* Function Declarations */
extern void pdist2(const double Xin[405916], const double Yin[28], double D[3],
                   double b_I[3]);

#endif

/*
 * File trailer for pdist2.h
 *
 * [EOF]
 */
